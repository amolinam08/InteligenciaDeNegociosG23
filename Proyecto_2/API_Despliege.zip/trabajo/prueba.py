# Instalación de librerias
import pandas as pd
import numpy as np
import sys

from sklearn.ensemble import RandomForestClassifier


from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer


import re, string, unicodedata
#import contractions
import inflect
from nltk import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import LancasterStemmer, WordNetLemmatizer

from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, HashingVectorizer


from sklearn.metrics import classification_report, confusion_matrix

import matplotlib.pyplot as plt


import pandas as pd
# Para preparar los datos
# Para crear el arbol de decisión
from sklearn.tree import DecisionTreeClassifier
# Para usar KNN como clasificador
# Para realizar la separación del conjunto de aprendizaje en entrenamiento y test.
from sklearn.model_selection import train_test_split
# Para evaluar el modelo
from sklearn.metrics import confusion_matrix, classification_report, precision_score, recall_score, f1_score, accuracy_score

# Versiones anteriores a 1.2 de sklearn: from sklearn.metrics import plot_confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

# Para búsqueda de hiperparámetros
from sklearn.model_selection import GridSearchCV
# Para la validación cruzada
from sklearn.model_selection import KFold
#Librerías para la visualización
import matplotlib.pyplot as plt
# Seaborn
import sklearn as sklearn



def texto_clasificado(archi):

    palt=None

    def remove_non_ascii(words):
        new_words = []
        for word in words:
            new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
            new_words.append(new_word)
        return new_words


    def to_lowercase(words):
        new_words = []
        for word in words:
            new_word = word.lower()  # Convierte la palabra a minúsculas
            new_words.append(new_word)
        return new_words


    def remove_punctuation(words):
        """Remove punctuation from list of tokenized words"""
        new_words = []
        for word in words:
            new_word = re.sub(r'[^\w\s]', '', word)
            if new_word != '':
                new_words.append(new_word)
        return new_words


    def replace_numbers(words):
        p = inflect.engine()
        new_words = []
        for word in words:
            if word.isdigit():
                new_word = p.number_to_words(word)
                new_words.append(new_word)
            else:
                new_words.append(word)
        return new_words


    def remove_stopwords(words):

        stop_words = set(stopwords.words('spanish'))  # Utilizamos 'spanish' para obtener la lista de palabras vacías en español
        new_words = [word for word in words if word.lower() not in stop_words]
        return new_words


    def preprocessing(words):
        words = to_lowercase(words)
        words = replace_numbers(words)
        words = remove_punctuation(words)
        words = remove_non_ascii(words)
        words = remove_stopwords(words)
        return words



    stemmer = SnowballStemmer("spanish")
    lemmatizer = WordNetLemmatizer()

    # Función para realizar stemming y lematización en español
    def stem_and_lemmatize(words):
        stems = [stemmer.stem(word) for word in words]
        lemmas = [lemmatizer.lemmatize(word, pos='v') for word in words]
        return stems + lemmas



    def texto_calificador(archivo):

        df = pd.read_csv('cat_6716.csv', delimiter=',')

        # Asignación a una nueva variable de los datos leidos
        data_t = df

        data_t


        data_t['palabras'] = data_t['Textos_espanol'].apply(word_tokenize).apply(preprocessing) #Aplica la eliminación del ruido

        archivo['palabras'] = archivo['Textos_espanol'].apply(word_tokenize).apply(preprocessing) #Aplica la eliminación del ruido


        data_t['palabras'] = data_t['palabras'].apply(stem_and_lemmatize)
        archivo['palabras'] = archivo['palabras'].apply(stem_and_lemmatize)


        data_t['palabras'] = data_t['palabras'].apply(lambda x: ' '.join(map(str, x)))

        archivo['palabras'] = archivo['palabras'].apply(lambda x: ' '.join(map(str, x)))

        X_data, y_data = data_t['palabras'],data_t['sdg']

        X_noetiqueta, y_noetiqueta = archivo['palabras'],archivo['sdg']

        vectorizer = CountVectorizer(binary=True)
        X_dummy = vectorizer.fit_transform(X_data)
        print(X_dummy.shape)
        X_dummy.toarray()[0]

        X2_dummy = vectorizer.transform(X_noetiqueta)
        X2_dummy.toarray()[0]


        rf_model = RandomForestClassifier(random_state=1)

        X_train, X_test, Y_train, Y_test = train_test_split(X_dummy, y_data, test_size=0.2, random_state=0)

        rf_model.fit(X_train, Y_train)

        preds_train_rf = rf_model.predict(X_train)
        preds_test_rf = rf_model.predict(X_test)

        predcition=rf_model.predict(X2_dummy)

        return predcition
    

    palt=texto_calificador(archi)
    

    return palt








    


