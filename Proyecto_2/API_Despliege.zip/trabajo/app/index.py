from distutils.log import error
from werkzeug.security import generate_password_hash, check_password_hash
from pickle import NONE
from flask import Flask,render_template,url_for,redirect,request,jsonify,Response
from flask_wtf import FlaskForm 
from wtforms.fields import DateField
from wtforms.validators import DataRequired
from flask_socketio import SocketIO, send
from wtforms import validators, SubmitField
from config import config
import csv
import pandas as pd



# Instalación de librerias
import pandas as pd
import numpy as np
import sys

from sklearn.ensemble import RandomForestClassifier


from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer


import re, string, unicodedata
#import contractions
import inflect
from nltk import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import LancasterStemmer, WordNetLemmatizer

from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, HashingVectorizer


from sklearn.metrics import classification_report, confusion_matrix

import matplotlib.pyplot as plt


import pandas as pd
# Para preparar los datos
# Para crear el arbol de decisión
from sklearn.tree import DecisionTreeClassifier
# Para usar KNN como clasificador
# Para realizar la separación del conjunto de aprendizaje en entrenamiento y test.
from sklearn.model_selection import train_test_split
# Para evaluar el modelo
from sklearn.metrics import confusion_matrix, classification_report, precision_score, recall_score, f1_score, accuracy_score

# Versiones anteriores a 1.2 de sklearn: from sklearn.metrics import plot_confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

# Para búsqueda de hiperparámetros
from sklearn.model_selection import GridSearchCV
# Para la validación cruzada
from sklearn.model_selection import KFold
#Librerías para la visualización
import matplotlib.pyplot as plt
# Seaborn
import sklearn as sklearn






from bson.objectid import ObjectId
from datetime import datetime
import json


class JSONEncoder (json .JSONEncoder) :

    def default (self,o):
        if isinstance (o,ObjectId):
            return str(o)
        if isinstance (o, datetime.datetime):
            return str(o)
        return json.JSONEncoder.default (self,o)









lista=[]
app=Flask(__name__)
usuario_ingresado=[]
user=None



# client = MongoClient("mongodb+srv://SantiagoVela:millos2011@cluster0.y1njt.mongodb.net/?retryWrites=true&w=majority")
# db = client.get_database('TA_db')




app.config['STATIC_FOLDER'] = 'static'


def texto_clasificado(archi):

    palt=[]

    def remove_non_ascii(words):
        new_words = []
        for word in words:
            new_word = unicodedata.normalize('NFKD', word).encode('ascii', 'ignore').decode('utf-8', 'ignore')
            new_words.append(new_word)
        return new_words


    def to_lowercase(words):
        new_words = []
        for word in words:
            new_word = word.lower()  # Convierte la palabra a minúsculas
            new_words.append(new_word)
        return new_words


    def remove_punctuation(words):
        """Remove punctuation from list of tokenized words"""
        new_words = []
        for word in words:
            new_word = re.sub(r'[^\w\s]', '', word)
            if new_word != '':
                new_words.append(new_word)
        return new_words


    def replace_numbers(words):
        p = inflect.engine()
        new_words = []
        for word in words:
            if word.isdigit():
                new_word = p.number_to_words(word)
                new_words.append(new_word)
            else:
                new_words.append(word)
        return new_words


    def remove_stopwords(words):

        stop_words = set(stopwords.words('spanish'))  # Utilizamos 'spanish' para obtener la lista de palabras vacías en español
        new_words = [word for word in words if word.lower() not in stop_words]
        return new_words


    def preprocessing(words):
        words = to_lowercase(words)
        words = replace_numbers(words)
        words = remove_punctuation(words)
        words = remove_non_ascii(words)
        words = remove_stopwords(words)
        return words



    stemmer = SnowballStemmer("spanish")
    lemmatizer = WordNetLemmatizer()

    # Función para realizar stemming y lematización en español
    def stem_and_lemmatize(words):
        stems = [stemmer.stem(word) for word in words]
        lemmas = [lemmatizer.lemmatize(word, pos='v') for word in words]
        return stems + lemmas



    def texto_calificador(archivo):
        info=[]

        df = pd.read_csv('cat_6716.csv', delimiter=';')

        # Asignación a una nueva variable de los datos leidos
        data_t = df

        data_t


        data_t['palabras'] = data_t['Textos_espanol'].apply(word_tokenize).apply(preprocessing) #Aplica la eliminación del ruido

        archivo['palabras'] = archivo['Textos_espanol'].apply(word_tokenize).apply(preprocessing) #Aplica la eliminación del ruido


        data_t['palabras'] = data_t['palabras'].apply(stem_and_lemmatize)
        archivo['palabras'] = archivo['palabras'].apply(stem_and_lemmatize)


        data_t['palabras'] = data_t['palabras'].apply(lambda x: ' '.join(map(str, x)))

        archivo['palabras'] = archivo['palabras'].apply(lambda x: ' '.join(map(str, x)))

        X_data, y_data = data_t['palabras'],data_t['sdg']

        X_noetiqueta, y_noetiqueta = archivo['palabras'],archivo['sdg']

        vectorizer = CountVectorizer(binary=True)
        X_dummy = vectorizer.fit_transform(X_data)
        print(X_dummy.shape)
        X_dummy.toarray()[0]

        X2_dummy = vectorizer.transform(X_noetiqueta)
        X2_dummy.toarray()[0]


        rf_model = RandomForestClassifier(random_state=1)

        X_train, X_test, Y_train, Y_test = train_test_split(X_dummy, y_data, test_size=0.2, random_state=0)

        rf_model.fit(X_train, Y_train)

        preds_train_rf = rf_model.predict(X_train)
        preds_test_rf = rf_model.predict(X_test)

        predcition=rf_model.predict(X2_dummy)


        metrics_df = pd.DataFrame([
        {
            'Train': accuracy_score(Y_train, preds_train_rf),
            'Test': accuracy_score(Y_test, preds_test_rf)
        },
        {
            'Train': precision_score(Y_train, preds_train_rf, average='weighted'),
            'Test': precision_score(Y_test, preds_test_rf, average='weighted')
        },
        {
            'Train': recall_score(Y_train, preds_train_rf, average='weighted'),
            'Test': recall_score(Y_test, preds_test_rf, average='weighted')
        },
        {
            'Train': f1_score(Y_train, preds_train_rf, average='weighted'),
            'Test': f1_score(Y_test, preds_test_rf, average='weighted')
        }
        ], index=['Accuracy', 'Precision', 'Recall', 'F1'])

        info.append(predcition)
        info.append(metrics_df)



        return info
    

    palt=texto_calificador(archi)


    

    return palt




    


# record_metas=db.metas
# records = db.ta_usuarios
# recordsIN = db.ta_usuariosInac




# hola1=records.find_one({'nombre' : "Julian David"})





events=[
{ 'title': 'Reporte del Dia',
  'start': '2022-07-18',
  'end': '',
  'url': 'https://docs.microsoft.com/es-es/power-bi/visuals/media/power-bi-line-charts/power-bi-single-select.png'
},
{
  'title': ' Reporte del dia',
  'start': '2022-07-10',
  'end': '2022-07-15',
  'url': 'https://www.insisoc.org/wp-content/uploads/2019/05/Análisis-de-oportunidades-Power-BI-Insisoc-Valladolid.png'


}
]





@app.route('/' )
def index():
    return redirect(url_for('login'))







@app.route('/agregar', methods=["GET", 'POST'])
def login():


    return render_template('main.html')


@app.route('/calendario')
def call() :


   
    return render_template('calendario.html',events=events)


@app.route('/add', methods=["GET", 'POST'])
def add() :
    if request.method == 'POST':
        title=request.form['title']
        start=request.form['start']
        end = request. form['end']
        url= request. form['url']
        if end=='':
            end=start
        events.append({'title':title,'start':start,'end':end,'url':url},)

    return render_template('add.html')



@app.route('/reporte' ,methods=["GET", 'POST'])
def report() :


    return render_template('reporte.html')









@app.route('/cambioContra' ) 
def cambioContra1():

    return render_template('cambioContra.html')


     

@app.route('/cambioC',methods=['POST'] ) 
def cambioC():

    documento=request.form['contra1']
    contra=request.form['contra2']

    texto_encriptado1 = generate_password_hash(contra)

    records.update_one({'documento' : documento}, {'$set' : {'contraseña':texto_encriptado1}})

    return redirect(url_for('cambioContra1')) 





   


@app.route('/creacion-usuarios')
def crudUsuarios():
    return render_template('prueba2.html')

@app.route('/creacion', methods=['POST'])
def prueba():

    archivo = request.files['archivo']

    unlabel=pd.read_csv(archivo, delimiter=',')


    jjj=texto_clasificado(unlabel)



    valores_unicos, recuentos = np.unique(jjj[0], return_counts=True)

    # Crea un diccionario que asocie cada valor único con su recuento
    conteo_valores = dict(zip(valores_unicos, recuentos))

    # Imprime el diccionario de conteo de valores repetidos
    print(conteo_valores)

   
     

    return render_template('prueba2.html', mensaje=conteo_valores, infor=jjj[1])

dtt = pd.read_csv('cat_6716.csv', delimiter=';')


# arreglar nombre del HTML
@app.route('/crud-lista')
def mostrar_csv():
    datos_dict = dtt.to_dict(orient='records')
    

    # Renderiza la plantilla HTML y pasa los datos del CSV como contexto
    return render_template('prueba1.html', datos=datos_dict)









@app.route('/crud-listain')
def crudInactivos():
    listain=list(recordsIN.find())
    return render_template('usuarioin.html',listaa=listain)




@app.route('/borrar/<string:names>',methods=['POST'])
def borrar(names):
    hola1=recordsIN.find_one({'nombre' : names})
    records.insert_one(hola1)
    recordsIN.delete_one({'nombre' : names})


    return redirect(url_for('crudInactivos'))




# arreglar nombre del HTML
@app.route('/delete/<string:name>')
def delete(name):

    records.update_one({'nombre' : name}, {'$set' : {'delete_por':usuario_ingresado[0]}})
    hola=records.find_one({'nombre' : name})

    recordsIN.insert_one(hola)



    records.delete_one({'nombre' : name})

    return redirect(url_for('crudlista'))






# arreglar fecha mod
@app.route('/edit/<string:name>', methods=['POST'])
def edit(name):

    nombre=request.form['nombre']
    apellido = request.form['apellido']
    documento= request.form['documento']
    sgi= request.form['sgi']
    contrasena= request.form['contrasena']
    correo= request.form['correo']

   # creador= request.form['creador']
    #Fcreador= request.form['Fcreador']


    if id and nombre and apellido and documento and sgi and contrasena and correo  :

        records.update_one({'nombre' : name}, {'$set' : {'nombre' : nombre, 'apellido' : apellido, 'documento' : documento,'sgi':sgi,'contraseña':contrasena,'correro':correo,"fecha_mod":str(datetime.today().strftime('%Y-%m-%d'))}})
        response = jsonify({'message' : 'Usuario ' + name + ' actualizado correctamente'})
        return redirect(url_for('crudlista'))
    else:
        return notFound()







@app.route('/editar/<string:product_name>', methods=['POST'])
def editarInac(product_name):

    nombre=request.form['nombre']
    apellido = request.form['apellido']
    documento= request.form['documento']
    sgi= request.form['sgi']
    contrasena= request.form['contrasena']
    permisos= request.form['permisos']
    correo= request.form['correo']
    activo= request.form['activo']
    fmod= str(datetime.today().strftime('%Y-%m-%d'))



    

   # creador= request.form['creador']
    #Fcreador= request.form['Fcreador']


    if id and nombre and apellido and documento and sgi and contrasena and correo and activo :

        records.update_one({'nombre' : product_name}, {'$set' : {'nombre' : nombre, 'apellido' : apellido, 'documento' : documento,'sgi':sgi,'contraseña':contrasena,'correro':correo,'activo':activo,'permisos':permisos,"fecha_mod": fmod}})
        response = jsonify({'message' : 'Usuario ' + product_name + ' actualizado correctamente'})
        return redirect(url_for('crudInactivos'))
    else:
        return notFound()


















@app.route('/metas' )
def metas() :
    return render_template('metas.html')



#arreglar lo de metas
@app.route('/crud-metas' ,methods=['POST'])
def CRUDmetas() :


    fecha=request.form['fecha']
    turno=request.form['turno']
    ancho = request.form['ancho']
    espesor= request.form['espesor']
    

    if fecha and turno and ancho and espesor :
        metaCreada= Metaa(fecha, turno, ancho, espesor)


        record_metas.insert_one(metaCreada.toDBCollection())

        response = jsonify({
            'fecha' : fecha,
            'turno' : turno,
            'ancho' : ancho,
            'espesor' : espesor

        })

        return redirect(url_for('metas')) 
    else:
        return notFound()



    


 
    return redirect(url_for('metas'))














@app.route('/listametas' )
def lista_metas() :
    usuario=usuario_ingresado[0]
    print(usuario)
    return render_template('listametas.html',data=usuario)





@app.errorhandler(404)
def notFound(error=None):
    message ={
        'message': 'No encontrado ' + request.url,
        'status': '404 Not Found'
    }
    response = jsonify(message)
    response.status_code = 404
    return response










def pagina_no_encontradada(error):
    return redirect(url_for('login'))




if __name__=='__main__':
    app.register_error_handler(404,pagina_no_encontradada)
    app.config.from_object(config['development'])
    app.run( port=3000)



