
btnfilterByName.onclick = function () { return applyFilterByName(); };
