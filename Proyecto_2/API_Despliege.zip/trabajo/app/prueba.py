import random
import csv

def test():
   with open('t_usuarios.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=',',
                            quoting=csv.QUOTE_MINIMAL)
    lista=[]                    
    for row in reader:
        lista.append(row)

    lista.pop(0)
    listaf=[]

    for i in range(len(lista)):
        dicci={
        "id_usuario":lista[i][0],
        "nombre":lista[i][1],
        "apellido":lista[i][2],
        "documento":lista[i][3],
        "sgi":lista[i][4],
        "contraseña":lista[i][3],
        "correro":lista[i][6],
        "activo":lista[i][7],
        "permisos":[],
        "creado_por":lista[i][8],
        "fecha_creado":lista[i][9],
        "mod_por":lista[i][10],
        "fecha_mod":lista[i][11],
        "delete_por":lista[i][12],
        "fecha_delete":lista[i][13]
        }
        listaf.append(dicci)
        dicci={}


    return(listaf)


