class Metaa:
    def __init__(self,fecha, turno, ancho, espesor):
        self.fecha = fecha
        self.turno = turno
        self.ancho = ancho
        self.espesor = espesor


    def toDBCollection(self):
        return{
            'fecha': self.id,
            'turno': self.nombre,
            'ancho': self.apellido,
            'espesor': self.documento
        }